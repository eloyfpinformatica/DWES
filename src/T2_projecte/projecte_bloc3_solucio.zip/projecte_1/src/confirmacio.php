<?php
    // Bloc 1 - Activitat 1.2
    //$autor = "Eloy";
    
    //Bloc 2 - Activitat 2.5
    define("AUTOR", "Eloy");

    // Bloc 2 - Activitat 2.2
    $nomClient = "Maria Garcia";
    $emailClient = "maria@acme.com";
    $empresaClient = "ACME Company";
    $empresaClient = null; // Bloc 3 - Activitat 3.1.
    $serveiClient = "Aplicació mòbil";
    $pressupostClient = 45000;
    $detallsProjecteClient = null; // Bloc 3 - Activitat 3.2.


?>
<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sol·licitud Rebudes | TechLeads</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-50 text-slate-800 font-sans min-h-screen flex flex-col justify-between">

    <header class="bg-white border-b border-slate-200 py-4 shadow-sm">
        <div class="max-w-6xl mx-auto px-6 flex justify-between items-center">
            <span class="font-extrabold text-2xl text-indigo-600">TechLeads</span>
        </div>
    </header>

    <main class="max-w-4xl mx-auto px-6 py-16 w-full text-center">

        <div class="bg-white p-8 rounded-2xl shadow-lg border border-slate-200">
            <div class="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                ✓
            </div>

            <h1 class="text-2xl font-bold text-slate-900 mb-2">Gràcies per la teua sol·licitud!</h1>
            <p class="text-slate-600 text-base mb-6">Hem rebut les teues dades correctament. Ens posarem en contacte amb tu en menys de 24 hores.</p>

            <!-- Resum de Dades Enviades (Estàtic) -->
            <div class="bg-slate-50 rounded-xl p-4 text-left border border-slate-200 space-y-2 text-base mb-6">
                <!-- Bloc 2 - Activitat 2.2. -->
                <p><strong class="text-slate-700">Nom:</strong> <?= $nomClient ?></p>
                <p><strong class="text-slate-700">Email:</strong> <?= $emailClient ?></p>
                <p><strong class="text-slate-700">Empresa:</strong> <?= $empresaClient ?? 'Sense especificar'?></p> <!-- Bloc 3 - Activitat 3.1. -->
                <p><strong class="text-slate-700">Servei:</strong> <?= $serveiClient ?></p>
                <p><strong class="text-slate-700">Pressupost estimat:</strong> <?= $pressupostClient  ?? 'Sense especificar' ?> €</p> <!-- Bloc 3 - Activitat 3.1. -->
                
                <!-- Bloc 3 - Activitat 3.2. -->
                 <?php if (!empty($detallsProjecteClient)) : ?>
                    <p><strong class="text-slate-700">Detalls del projecte:</strong> <?= $detallsProjecteClient ?></p>
                <?php endif; ?>
            </div>

            <a href="index.php" class="inline-block bg-slate-900 hover:bg-slate-800 text-white font-medium text-sm px-5 py-2.5 rounded-lg transition">
                Tornar a l'inici
            </a>
        </div>

    </main>

    <footer class="bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-500">
        <!-- Bloc 1 - Activitat 1.2 -->
        <!-- <p>TechLeads &copy; 2026 — Tots els drets reservats — $autor.</p> -->
    
        <!-- Bloc 2 - Activitat 1.5 -->
        <p>TechLeads &copy; 2026 — Tots els drets reservats — <?= AUTOR ?>.</p>
    </footer>

</body>
</html>