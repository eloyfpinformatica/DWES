<?php
// Bloc 5 - Activitat 5.3
function etiquetes_estat(string $estat): string
{
    $color = match ($estat) {
        'nou'                  => "green",
        'contactat'            => "yellow",
        'convertit', 'guanyat' => "green",
        default                => "gray"
    };

    $etiqueta = "<span class=\"bg-{$color}-100 text-{$color}-800 text-xs font-medium px-1.5 py-0.5 rounded\">{$estat}</span>";

    return $etiqueta;
}